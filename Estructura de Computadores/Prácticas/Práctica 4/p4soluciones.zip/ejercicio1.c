//ALGORITMO Convierte_segs 
//ENTRADAS:
//  Segs: Entero ; Número leído 
//SALIDAS:
//VARIABLES 
//  Segs: Entero 
//  Mins: Entero 
//  Horas: Entero 
//  Dias: Entero
//INICIO 
//  ESCRIBA “Escribe un número de segundos: ” 
//  LEA Segs 
//  SI Segs < 0 ENTONCES
//      ESCRIBA “Error. Debe indicar un número positivo”
//  SINO 
//      Dias = 0
//      Horas = 0
//      Mins = 0
//      SI Segs > 59 ENTONCES
//           Mins = Segs / 60 
//           Segs = Segs mod 60
//           SI Mins > 59 ENTONCES 
//               Horas = Mins / 60
//               Mins = Mins mod 60
//               SI Horas > 23 ENTONCES
//                    Dias = Horas / 24 
//                    Horas = Horas mod 24
//               FINSI
//           FINSI
//      FINSI
//      ESCRIBA “El número de segundos se corresponde con “, Dias, “ días,”, Horas, “ horas,”, Mins “ minutos y ”, Segs, “ segundos.”
//  FINSI 
//FIN



//Librería que contiene las funciones scanf y printf

#include <stdio.h> 

//Función principal del programa

int main () 

{
	
	// Este programa convierte a días, horas, minutos y segundos una cantidad de segundos
	
	// Declaro las variables de mi función 
	
	int Segs, Mins, Horas, Dias;
	
	//Sustituyo la función ESCRIBA “cadena” por printf
	
	printf("Escribe un número de segundos: "); 
	
	//Sustituyo la función LEA Segs por scanf (“%d”, &variableEntera);
	
	scanf("%d", &Segs); //Guarda el número leído en la variable Segs 
	
		
	//Compruebo si el número introducido es mayor o igual que 0
	
	if (Segs < 0) 
	{
		//Sustituyo la función ESCRIBA “cadena” por printf
		
		printf("Error. Debe indicar un número positivo!"); 
		
	}	
	else 
	{
		// Inicializo las variables:
		Dias=0;
		Horas=0;
		Mins=0;
		
		if (Segs > 59) 
		{
			Mins = Segs / 60;
			Segs = Segs % 60;
			if (Mins > 59) 
			{
				Horas = Mins / 60;
				Mins = Mins % 60;
				if (Horas > 23) 
				{
					Dias = Horas / 24; 
					Horas = Horas % 24;
				}
			}

		}	
		//Sustituyo la función ESCRIBA “cadena” por printf
		printf("El número de segundos se corresponde con %d días, %d horas, %d minutos y %d Segs.", Dias, Horas, Mins, Segs); 	
			
	}
	
		
	//Fin del programa
	
	return 0;
	
}