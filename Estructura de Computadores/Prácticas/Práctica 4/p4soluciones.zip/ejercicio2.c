//ALGORITMO Factorial
// ENTRADAS:
//   Num: Entero ; Número leído
// SALIDAS:
//   Fact: Entero ; Factorial
// VARIABLES
//   Num: Entero 
//   Fact: Entero 
// INICIO  
//   ESCRIBA “Escribe un número: ”
//   LEA Num
//   Fact = 1
//	 SI Num > 0 ENTONCES
//      MIENTRAS Num>0 HACER
//        Fact = Fact * Num
//        Num = Num - 1
//      FINMIENTRAS
//      ESCRIBA “El factorial del número es “
//      ESCRIBA Fact
//   SINO
//      ESCRIBA "Error, tiene que ser un número positivo"
//   FINSI
//FIN


//Librería que contiene las funciones scanf y printf

#include <stdio.h> 

//Función principal del programa

int main () 

{
	
	// Este programa calcula el factorial de un número  
	
	// Declaro las variables de mi función
	
	int Num, Fact;
	
	//Sustituyo la función ESCRIBA “cadena” por printf
	
	printf("Escribe un número: "); 
	
	//Sustituyo la función LEA Num por scanf (“%d”, &variableEntera);
	
	scanf("%d", &Num); //Guarda el número leído en la variable Num 
	
	
	//Inicializo el factorial
	Fact=1;
	
	//Compruebo que el número es mayor que 0
	
	if (Num > 0)
	{
		
		//Bucle
		while(Num > 0)
		{
			Fact = Fact * Num;
			Num = Num - 1;
		}
		
		printf("El factorial del número es %d", Fact);
		
	}
	
	else
	{
		
		//Sustituyo la función ESCRIBA “cadena” por printf
		
		printf("El número ha de ser positivo");
		
	}
	
	//Fin del programa
	
	return 0;
	
}